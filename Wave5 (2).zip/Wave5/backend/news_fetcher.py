import requests

API_KEY = "017d7d3473fc418290a32912f648b1d9"

def fetch_news():
    url = f"https://newsapi.org/v2/everything?q=disease OR outbreak OR virus OR infection&language=en&sortBy=publishedAt&apiKey={API_KEY}"
    
    try:
        response = requests.get(url, timeout=10)
        response.raise_for_status()
        data = response.json()
        
        articles = []
        for article in data.get("articles", []):
            if article.get("title") or article.get("description"):
                title = article.get("title", "") or ""
                description = article.get("description", "") or ""
                text = f"{title} {description}".strip()
                
                source = "Unknown"
                if article.get("source") and article.get("source").get("name"):
                    source = article["source"]["name"]
                    
                articles.append({
                    "text": text,
                    "source": source
                })
        return articles
    except Exception as e:
        print(f"Error fetching news: {e}")
        return []