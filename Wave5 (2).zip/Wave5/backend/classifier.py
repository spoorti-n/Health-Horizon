DISEASE_KEYWORDS = [
    "dengue", "flu", "influenza", "virus", "infection",
    "epidemic", "pandemic", "cholera", "malaria", "covid",
    "sepsis", "respiratory illness", "hospital cases", 
    "health emergency", "disease outbreak"
]

POPULATION_LOCATION_KEYWORDS = [
    "hospital", "city", "state", "country", "patients",
    "cases", "workers", "community", "region"
]

REJECT_KEYWORDS = [
    "tortoise", "ferret", "bird", "fish", "dog", "cat", 
    "wildlife", "animal", "coyote", "crow", "ransomware", 
    "cyber attack", "technology", "fire outbreak", "violence outbreak"
]

def is_health_signal(text):
    text = text.lower()

    # Reject unrelated topics, animals, and non-health outbreaks
    for reject in REJECT_KEYWORDS:
        if reject in text:
            return False

    # Must contain at least one explicit disease terminology
    has_disease = any(keyword in text for keyword in DISEASE_KEYWORDS)
    
    # Must contain at least one population or location context
    has_population_location = any(keyword in text for keyword in POPULATION_LOCATION_KEYWORDS)
    
    return has_disease and has_population_location