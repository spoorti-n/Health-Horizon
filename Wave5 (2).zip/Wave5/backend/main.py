from fastapi import FastAPI
from services import process_outbreaks, get_raw_signals, get_sources_stats

app = FastAPI(title="Disease Monitor API")

@app.get("/health")
def health_check():
    return {"status": "API running"}

@app.get("/outbreaks")
def get_outbreaks():
    try:
        return process_outbreaks()
    except Exception as e:
        print(f"Unhandled error in get_outbreaks: {e}")
        return []

@app.get("/signals")
def get_signals():
    try:
        return get_raw_signals()
    except Exception as e:
        print(f"Unhandled error in get_signals: {e}")
        return []

@app.get("/sources")
def get_sources():
    try:
        return get_sources_stats()
    except Exception as e:
        print(f"Unhandled error in get_sources: {e}")
        return {"NewsAPI": 0, "GDELT": 0}