const express = require('express');
const cors = require('cors');
const axios = require('axios');
const mongoose = require('mongoose');

const app = express();
const port = 8080;

app.use(cors({
    origin: '*', // Allow all origins for development (or specify 'http://localhost:8081')
    methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
    allowedHeaders: ['Content-Type', 'Authorization']
}));
app.use(express.json());

// MongoDB Connection
mongoose.connect("mongodb://localhost:27017/healthhorizon")
    .then(() => console.log('Successfully connected to MongoDB: healthhorizon'))
    .catch(err => console.error('MongoDB connection error:', err));

// Outbreak Schema
const outbreakSchema = new mongoose.Schema({
    disease: String,
    location: String,
    cases: Number,
    riskLevel: String,
    latitude: Number,
    longitude: Number,
    source: String,
    link: String,
    hospital: String,
    timestamp: { type: Date, default: Date.now }
});

const Outbreak = mongoose.model('Outbreak', outbreakSchema);

// Mock Data (Static)
const staticOutbreaks = [
    {
        disease: 'Dengue',
        location: 'Bangalore',
        riskLevel: 'High',
        cases: 120,
        latitude: 12.9716,
        longitude: 77.5946,
        source: 'Static'
    },
    {
        disease: 'Flu',
        location: 'Delhi',
        riskLevel: 'Medium',
        cases: 60,
        latitude: 28.7041,
        longitude: 77.1025,
        source: 'Static'
    },
    {
        disease: 'Malaria',
        location: 'Mumbai',
        riskLevel: 'Low',
        cases: 30,
        latitude: 19.0760,
        longitude: 72.8777,
        source: 'Static'
    }
];

const alerts = [
    {
        id: 1,
        title: 'High Risk Alert: Dengue in Bangalore',
        severity: 'high',
        message: 'Dengue cases have crossed 100 in Bangalore. Immediate action required.'
    },
    {
        id: 2,
        title: 'Medium Risk Alert: Flu in Delhi',
        severity: 'medium',
        message: 'Flu cases are rising in Delhi. Monitoring advised.'
    }
];

// NLP Module Constants
const diseaseKeywords = ['dengue', 'malaria', 'flu', 'covid', 'cholera', 'viral fever', 'infection'];
const locations = {
    'Bangalore': { latitude: 12.9716, longitude: 77.5946 },
    'Delhi': { latitude: 28.7041, longitude: 77.1025 },
    'Mumbai': { latitude: 19.0760, longitude: 72.8777 }
};

// 6. Prevent Duplicate Entries & Save Logic
async function saveOrUpdateOutbreak(data) {
    const thirtyMinsAgo = new Date(Date.now() - 30 * 60 * 1000);
    
    try {
        // Check if same disease and location exists within the last 30 minutes
        const existing = await Outbreak.findOne({
            disease: data.disease,
            location: data.location,
            timestamp: { $gte: thirtyMinsAgo }
        });

        if (existing) {
            // Update the case count instead of creating a new record
            existing.cases = data.cases;
            existing.riskLevel = data.riskLevel;
            existing.timestamp = new Date(); // Update timestamp to extend window if needed
            await existing.save();
            console.log(`Updated existing record: ${data.disease} in ${data.location}`);
            return existing;
        } else {
            // Create new record
            const fresh = new Outbreak(data);
            await fresh.save();
            console.log(`Saved new record: ${data.disease} in ${data.location}`);
            return fresh;
        }
    } catch (err) {
        console.error('Error in saveOrUpdateOutbreak:', err);
    }
}

// NLP Detection Module
function detectDiseaseSignals(text) {
    if (!text) return null;
    const lowercaseText = text.toLowerCase();
    const detectedDisease = diseaseKeywords.find(keyword => lowercaseText.includes(keyword));
    const detectedLocationName = Object.keys(locations).find(loc => lowercaseText.includes(loc.toLowerCase()));

    if (detectedDisease && detectedLocationName) {
        const cases = Math.floor(Math.random() * (150 - 20 + 1)) + 20;
        let riskLevel = 'Low';
        if (cases > 100) riskLevel = 'High';
        else if (cases > 50) riskLevel = 'Medium';

        return {
            disease: detectedDisease.charAt(0).toUpperCase() + detectedDisease.slice(1),
            location: detectedLocationName,
            riskLevel: riskLevel,
            cases: cases,
            latitude: locations[detectedLocationName].latitude,
            longitude: locations[detectedLocationName].longitude
        };
    }
    return null;
}

// 2. News Data Collector
const NEWS_API_KEY = 'YOUR_NEWS_API_KEY_HERE'; 

async function fetchNewsSignals() {
    console.log(`[${new Date().toLocaleTimeString()}] Fetching News signals...`);
    try {
        const response = await axios.get(`https://newsapi.org/v2/everything?q=disease OR outbreak&apiKey=${NEWS_API_KEY}`);
        const articles = response.data.articles || [];

        for (const article of articles) {
            const combinedText = `${article.title} ${article.description}`;
            const outbreakData = detectDiseaseSignals(combinedText);
            if (outbreakData) {
                await saveOrUpdateOutbreak({ 
                    ...outbreakData, 
                    source: 'NewsAPI', 
                    link: article.url 
                });
            }
        }
    } catch (error) {
        console.error('Error fetching News signals:', error.message);
    }
}

// 3. Social Media Data Collector (Reddit)
async function fetchSocialSignals() {
    console.log(`[${new Date().toLocaleTimeString()}] Fetching Reddit signals...`);
    try {
        const response = await axios.get('https://www.reddit.com/search.json?q=disease');
        const posts = response.data.data.children || [];

        for (const post of posts) {
            const title = post.data.title;
            const outbreakData = detectDiseaseSignals(title);
            if (outbreakData) {
                await saveOrUpdateOutbreak({ 
                    ...outbreakData, 
                    source: 'Reddit', 
                    link: `https://reddit.com${post.data.permalink}` 
                });
            }
        }
        console.log(`[${new Date().toLocaleTimeString()}] Reddit fetch cycle complete.`);
    } catch (error) {
        console.error('Error fetching Reddit signals:', error.message);
    }
}

// Initial Data Fetch
fetchNewsSignals();
fetchSocialSignals();

// 6. Schedule Data Updates
setInterval(fetchNewsSignals, 300000); // 5 minutes
setInterval(fetchSocialSignals, 180000); // 3 minutes

// --- Analytics & Predictions Logic ---

async function calculateDiseaseTrends() {
    console.log(`[${new Date().toLocaleTimeString()}] Calculating disease trends...`);
    try {
        const stats = await Outbreak.aggregate([
            {
                $group: {
                    _id: "$disease",
                    totalReports: { $sum: 1 },
                    totalCases: { $sum: "$cases" },
                    averageCases: { $avg: "$cases" },
                    // Get cases over time to determine trend
                    caseHistory: { $push: { cases: "$cases", timestamp: "$timestamp" } }
                }
            }
        ]);

        return stats.map(s => {
            // Simple trend logic: compare latest average cases with overall average
            const sortedHistory = s.caseHistory.sort((a, b) => b.timestamp - a.timestamp);
            const latestCases = sortedHistory[0]?.cases || 0;
            let trend = "stable";
            if (latestCases > s.averageCases * 1.2) trend = "increasing";
            else if (latestCases < s.averageCases * 0.8) trend = "decreasing";

            return {
                disease: s._id,
                totalReports: s.totalReports,
                totalCases: s.totalCases,
                averageCases: Math.round(s.averageCases),
                trend: trend
            };
        });
    } catch (err) {
        console.error('Error calculating disease trends:', err);
        return [];
    }
}

async function predictOutbreakRisk() {
    const twentyFourHoursAgo = new Date(Date.now() - 24 * 60 * 60 * 1000);
    
    try {
        const recentOutbreaks = await Outbreak.find({ timestamp: { $gte: twentyFourHoursAgo } });
        
        // Group by location and disease for prediction
        const groupings = {};
        recentOutbreaks.forEach(ob => {
            const key = `${ob.location}-${ob.disease}`;
            if (!groupings[key]) groupings[key] = { reports: 0, totalCases: 0, disease: ob.disease, location: ob.location };
            groupings[key].reports += 1;
            groupings[key].totalCases += ob.cases;
        });

        return Object.values(groupings).map(g => {
            // Simple scoring: 
            // - Each report adds 10 points
            // - Each 50 cases add 15 points
            // - Cap at 100
            let score = (g.reports * 10) + (Math.floor(g.totalCases / 50) * 15);
            score = Math.min(score, 100);

            return {
                disease: g.disease,
                location: g.location,
                riskProbability: score
            };
        });
    } catch (err) {
        console.error('Error generating predictions:', err);
        return [];
    }
}

let cachedAnalytics = [];

async function updateAnalytics() {
    cachedAnalytics = await calculateDiseaseTrends();
}

// Initial calculation
updateAnalytics();

// 5. Schedule Trend Updates (10 minutes)
setInterval(updateAnalytics, 600000);

// API Endpoints
// 3. GET /api/analytics
app.get('/api/analytics', (req, res) => {
    res.json({ diseases: cachedAnalytics });
});

// 4. GET /api/predictions
app.get('/api/predictions', async (req, res) => {
    const predictions = await predictOutbreakRisk();
    res.json(predictions);
});

// 5. Update API Endpoint (Fetch from MongoDB)
app.get('/api/outbreaks', async (req, res) => {
    try {
        // Fetch latest 200 outbreak records from MongoDB, sorted by timestamp descending
        const dbRecords = await Outbreak.find().sort({ timestamp: -1 }).limit(200);
        
        // Merge with static data for consistency if desired, or just return DB
        const mergedOutbreaks = [
            ...staticOutbreaks,
            ...dbRecords
        ];
        res.json(mergedOutbreaks);
    } catch (err) {
        res.status(500).json({ error: 'Failed to fetch outbreaks' });
    }
});

// 4. Hospital Report Upload Endpoint
app.post('/api/hospital-report', async (req, res) => {
    const { hospital, location, disease, cases } = req.body;

    if (!location || !disease || cases === undefined) {
        return res.status(400).json({ error: 'Missing required fields: location, disease, cases' });
    }

    const locationData = locations[location];
    if (!locationData) {
        return res.status(400).json({ error: 'Unsupported location' });
    }

    let riskLevel = 'Low';
    if (cases > 100) riskLevel = 'High';
    else if (cases > 50) riskLevel = 'Medium';

    const outbreakData = {
        disease: disease,
        location: location,
        riskLevel: riskLevel,
        cases: parseInt(cases),
        latitude: locationData.latitude,
        longitude: locationData.longitude,
        source: 'Hospital Report',
        hospital: hospital,
        timestamp: new Date()
    };

    const saved = await saveOrUpdateOutbreak(outbreakData);
    res.status(201).json({ message: 'Report submitted successfully', outbreak: saved });
});

app.get('/api/alerts', (req, res) => {
    res.json(alerts);
});

app.listen(port, () => {
    console.log(`Backend server listening at http://localhost:${port}`);
});
