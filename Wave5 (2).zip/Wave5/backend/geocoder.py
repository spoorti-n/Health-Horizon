from geopy.geocoders import Nominatim
from geopy.exc import GeocoderTimedOut, GeocoderServiceError

geolocator = Nominatim(user_agent="disease_monitor_app")

def geocode_location(city: str):
    """
    Takes a city or region string, resolves its latitude and longitude.
    Returns a dictionary or None if it cannot be resolved.
    """
    try:
        # Resolve the location using Nominatim. Timeout sets how long we're willing to wait.
        location = geolocator.geocode(city, timeout=5)
        
        if location:
            return {
                "city": city,
                "lat": float(location.latitude),
                "lng": float(location.longitude)
            }
    except (GeocoderTimedOut, GeocoderServiceError, Exception) as e:
        print(f"Geocoding error for {city}: {e}")
        return None
        
    return None